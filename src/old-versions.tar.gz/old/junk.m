        #def T(self, t):

                #R = matrix(CDF, self.p+1);

                ## Scalar used for e_infty 
                #scalar_e_infty = self.character[t];

                ## Scalar used for e_u
                #scalar_e_u     = self.character[modinv(t, self.p)];

                ## Each element 1,...,p
                #for u in range(1, self.p+1):
                        ## The action permutes the indices of the basis 
                        #new_u = mod((t**2)*u, self.p);

                        ## Must decrement element values by one to get 
                        ## matrix index values (indexing starts at 0).
                        #R[u-1, new_u-1] = scalar_e_u;

                ## e_infty is always stable
                #R[self.p, self.p] = scalar_e_infty;

                #return self.cob * R * self.cob.inverse();





PRIME = 11;
PRIMITIVE_ROOT = 2; % can be anything nonzero above 1 (non-1?)

function xInv = modInv(x,n)
% ModInv(x,n) computes the multiplicative inverse of x modulo n if one
% % exists; errors if no such inverse exists
 if gcd(x,n) ~= 1
     error('x has no inverse modulo n')
end

     [d, a, b]   = gcd(x,n);
     xInv        = mod(a,n);
end




function metadata = make_metadata(prim_root, q)

        metadata = struct(
                'prim_root',    prim_root,
                'q',            q,
                'index_to_value', zeros(1,q), 
                'index_to_power', zeros(1,q), 
                'value_to_index', zeros(1,q), 
                'power_to_index', zeros(1,q),
                'value_to_power', zeros(1,q),
                'mx', zeros(q+1)
        );

        num_distinct_powers = q-1;

        n_evens = floor(num_distinct_powers/2);
        n_odds  = num_distinct_powers - n_evens;

        % pow - power of the primitive root of unity
        % val - value of prim_root^pow (mod q)
        % idx - position of things in the order given in paper 

        for pow=1:num_distinct_powers 

                if mod(pow,2) == 0
                        % Even powers of the root go first, 
                        idx = pow/2;
                else
                        % Then odd powers of the root
                        idx = n_evens + ceil(pow/2);
                end

                val = mod(prim_root^pow, q);

                metadata.index_to_value(idx) = val;
                metadata.index_to_power(idx) = pow;
                metadata.power_to_index(pow) = idx;
                metadata.value_to_index(val) = idx;
                metadata.value_to_power(val) = pow;
        end

        % Choice of primitive root induces a permutation
        % on VALUES 1,...,q-1.
        %R = zeros(q+1);

        %R(q, q)     = 1;
        %R(q+1, q+1) = 1;



        %for pow=1:q+1
                %case i 
                %of 1 do 
                        %% e_0 -> q
                        %metadata.mx(q, i) = 1;
                        %break;
                %of q+1 do
                        %% e_inf -> q+1
                        %metadata.mx(q+1,q+1) = 1;
                        %break;
                %otherwise do
                        %if mod(i,2) = 0
                                %metadata.mx(
                %end
                %if 
                %metadata.mx(i
                 
                
end

%function P = shift_perm_matrix(m, a) 

        %P = zeros(m.q + 1);

        %for i=1:m.q
                %P(mod(i-a, m.q)+1, i) = 1;
        %end
%end


% 
% COLUMNS ARE BASIS "VECTORS" (actually functions)
%
function M = basis_for_induced_vs(meta)

        % The dimensions of the vector space induced in
        % this way is a function of q alone and independent
        % on the choice of character representation \psi.

        basis_matrix = zeros(meta.q + 1);

        % There are q elements of F_q, and one special infty element 
        for pow=1:meta.q-1
                col = meta.power_to_index(pow);
                row = mod(meta.prim_root^pow, meta.q);

                % Write a 1 to the proper position.
                basis_matrix(row, col) = 1;
        end

        % Set a 1 in the position corresponding to e_0.
        basis_matrix(meta.q, meta.q) = 1;

        % Finally, set a 1 in the last position corresponding to e_infty.
        basis_matrix(meta.q+1, meta.q+1) = 1;

        M = basis_matrix;
end


% Remember subgroup U is isomorphic to just the field K as an (additive) group ?
% so u can come from this group

% this should be done as a set of permutation matrices with multiplication
% but until then it is like this...

%
%       Essentially once you fix your initial basis matrix,
%       the shifts by successive u correspond to shifting
%       that matrix UP by one step and wrapping around.
%
%               1 0 0    0 1 0    0 0 0    1 0 0
%               0 1 0 => 0 0 0 => 1 0 0 => 0 1 0
%               0 0 0    1 0 0    0 1 0    0 0 0 
%
function M = representation_U(meta, u)

        rep = zeros(meta.q + 1);

        % There are q elements of F_q, and one special infty element 
        for idx=1:meta.q-1

                v  = meta.index_to_value(idx);
                vv = mod(v - u, meta.q)

                if vv == 0
                        vv = meta.q;
                end

                col = idx;
                row = vv;

                rep(row, col) = 1;
        end
        
        % Finally, set a 1 in the last position corresponding to e_infty.
        rep(meta.q+1, meta.q+1) = 1;

        M = rep;
end


function M = representation_T(meta, a)

        rep = zeros(meta.q + 1);

        % There are q elements of F_q, and one special infty element 
        for idx=1:meta.q-1
        % fix these damn indexes...

                v  = meta.index_to_value(idx)
                vv = mod((a^2)*v, meta.q)

                if vv == 0
                        vv = meta.q; % ??
                end

                ii = meta.value_to_index(vv);

                col = ii;
                row = v;

                %rep(row, col) = phi(modInv(a, meta.q));
                %rep(row, col) = phi(meta.q, 1, -1);
                rep(row,col) = 1;
                %M = phi(modInv(a, meta.q)) * rep;
        end
        
        % Finally, set a 1 in the last position corresponding to e_infty.
        rep(meta.q+1, meta.q+1) = 1; %phi(meta.q, 1, 1);

        M = rep;
end


function rep = rep_U(cob, q, a)

        % All representations are linear transformations 
        % in a (q+1)-dimensional vector space. 
        rep = zeros(q + 1);

        % The subgroup U is isomorphic to the finite field Z/qZ.
        for u=1:q
                if u == q
                        % The COB matrix is only (q-1)-dimensional,
                        % because it only represents (Z/qZ)*.
                        % 
                        % So we can't ask it for the position of 
                        % u = q. But we don't need to. We interpret 
                        % u = q as u = 0, since q = 0 (mod q), and 
                        % the position of e_0 is fixed at column q 
                        % in our order.
                        pos_u = q;
                else
                        % Position of u in basis order
                        pos_u = u;
                        %pos_u = find(cob(u,:));
                end

                % The shifted value of the 'u'.
                new_u = mod(u-a, q);

                if new_u == 0 
                        % i.e. if 'u' == 'a', then we
                        % send it to the position of
                        % e_0, which is column 'q'.
                        pos_new_u = q;
                else 
                        % Position of the new 'u'.
                        pos_new_u = new_u;
                        %pos_new_u = find(cob(new_u, :));
                end

                % We permute pos_u => pos_new_u 
                rep(pos_u, pos_new_u) = 1;
        end

        % e_infty is always stable.
        rep(q+1,q+1) = 1;

        cob(q,q) = 1;
        cob(q+1,q+1) = 1;

        rep = cob * rep * inv(cob);

        return 
end




function rep = rep_T(cob, q, t)

        % All representations are linear transformations 
        % in a (q+1)-dimensional vector space. 
        rep = zeros(q + 1);

        %for u=1:q
                %fprintf('t=%d, u=%d: %d => %d\n', t, u, mod(u, q), mod((t^2)*u, q));
        %end

        % The subgroup U is isomorphic to the finite field Z/qZ.
        for u=1:q
                %if u == q 
                        %% The COB matrix is only (q-1)-dimensional,
                        %% because it only represents (Z/qZ)*.
                        %% 
                        %% So we can't ask it for the position of 
                        %% u = q. But we don't need to. We interpret 
                        %% u = q as u = 0, since q = 0 (mod q), and 
                        %% the position of e_0 is fixed at column q 
                        %% in our order.
                        %pos_u = q;
                %else
                        % Position of u in basis order
                        %pos_u = u;%find(cob(u,:));
                        %pos_u = find(cob(u,:));
                        pos_u = u;
                %end

                % The shifted value of the 'u'.
                new_u = mod((t^2)*u, q);

                if new_u == 0
                        pos_new_u = q;
                else
                        pos_new_u = new_u;
                end

                %if pos_new_u == q
                        
                        
                        

                %if new_u == 0 
                        %% i.e. if 'u' == 'a', then we
                        %% send it to the position of
                        %% e_0, which is column 'q'.
                        %%pos_new_u = 1;
                %else 
                        %% Position of the new 'u'.
                        %%pos_new_u = new_u; %find(cob(new_u, :));
                        %%pos_new_u = find(cob(new_u, :));
                        %%pos_new_u = new_u;
                %end

                % We permute pos_u => pos_new_u 
                rep(pos_u, pos_new_u) = 1;
        end

        % e_infty is always stable.
        rep(q+1,q+1) = 1;

        cob(q,q) = 1;
        cob(q+1,q+1) = 1;

        rep = cob * rep * inv(cob);

        return 
end


def permutation_from_primitive_root(p, r):
        
        # Matrix really only needs to be (p-1)x(p-1), but we extend by ident
        # because this is what we will eventually be working with.
        M = matrix(p+1);

        # From 1,...,p-1, all the powers of the unit group (F_p)*
        for i in range(1, p):
                M[i-1, mod(r**i, p)-1] = 1;

        # Extend by ident
        M[p-1,p-1] = 1;
        M[p,p]     = 1;

        return M


def permutation_princ_series_basis(p):

        # Matrix really only needs to be (p-1)x(p-1), but we extend by ident
        # because this is what we will eventually be working with.
        M = matrix(p+1);

        n_evens = floor((p-1)/2);

        for i in range(1, p):
                if mod(i,2) == 0:
                        M[(i/2) - 1, i - 1] = 1;
                else:
                        # Float prevents stupid integer division to 0 for 1/2
                        M[n_evens + ceil(float(i)/float(2)) - 1, i - 1] = 1;

        # Extend by ident
        M[p-1,p-1] = 1;
        M[p,p]     = 1;

        return M


def get_princ_series_cob(p,r):
        pp = permutation_from_primitive_root(p, r);
        pr = permutation_princ_series_basis(p);

        return pr * pp;


def get_disc_series_cob(p,r):
        return permutation_from_primitive_root(p, r);


def princ_rep_U(cob, p, a):

        rep = matrix(p+1);

        # The subgroup U is isomorphic to Z/pZ considered as a group
        # additively.
        #
        # 'u' over every element in finite field Z/pZ  
        # (remember range goes 1,..,p+1-1=p)
        # TODO: 
        # should this be additive??? Or multiplicative???)
        for u in range(1, p+1):
                
                # Shifted value of the 'u'
                new_u = mod(u - a, p);

                if new_u == 0:
                        # i.e. if 'u' == 'a' then we
                        # send it to the position of e_0,
                        # which is column 'p'.
                        new_u = p;

                rep[u-1, new_u-1] = 1;

        # e_infty is always stable.
        rep[p+1 - 1, p+1 - 1] = 1;

        # Shift into the re-ordered basis relative to a fixed root of unity.
        return cob * rep * cob.inverse();

                        
def princ_rep_T(cob, p, t):

        rep = matrix(p+1);

        # The subgroup T is isomorphic to (Z/pZ)*
        for u in range(1,p+1):

                # The shifted 'u'
                new_u = mod((t**2)*u, p);

                if new_u == 0:
                        # As above
                        new_u = p;

                rep[u - 1, new_u - 1] = 1;

        # e_infty is always stable
        rep[p+1 - 1, p+1 - 1] = 1;

        return cob * rep * cob.inverse();
