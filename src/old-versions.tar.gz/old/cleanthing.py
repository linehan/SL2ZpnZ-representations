#!/usr/bin/env sage

import sys
from sage.all import *


"""
Helper functions
"""
def xgcd(a,b):
        x, prevx = 0, 1;
        y, prevy = 1, 0;

        while b:
                q = a/b
                x, prevx = prevx - q*x, x
                y, prevy = prevy - q*y, y
                a, b = b, a % b
        
        return a, prevx, prevy


"""
Compute the modular multiplicative inverse
"""
def modinv(a, m):
        g, x, y = xgcd(a, m)
        
        if g != 1:
                raise Exception('modular inverse does not exist')
        else:
                return x % m




"""
        maps K^* -> C
"""
def jay(z, char, p, L_gen):

        # DENOTE the base field as K and the quadratic extension as L. 
        # 
        # For example, if K = F_p, L = F_{p^2}.

        s = 0;

        # 0,...,p^2-1  (L -- we filter out non-units manually to get L^*)
        c = 0;
        for n in range(0, p**2):

                # For each element of L
                l = L_gen**n;

                # For each element of (L^*) 
                if l.is_unit() == False:
                        c = c + 1;
                        continue;

                # This is the field norm N:L->K. 
                # It is surjective onto K^* (see Rockmore+Lafferty).
                #
                # In a finite Galois extension L=GF(q^n) of K=GF(q),
                # for all a \in L, the field norm can be written 
                #
                #       N(a^q) = N(a) = a^{(q^n-1)/(q-1)}. 
                #
                # In our case, n=2, hence
                #
                #       N(a^q) = N(a) = a^{(q^2-1)/(q-1)} 
                #                     = a^(q+1).
                #
                norm = l**(p + 1);

                if norm == z:
                        #tr  = (l**p) + l; # Another way to compute the trace 
                        #print(tr == l.trace());
                        tr = l.trace();

                        # The denominator 'p' is correct (not p-1). See paper.
                        ch = complex(exp(2.0*pi*I*float(int(tr))/float(p)));

                        s = s + ch * char[n];

        print("ONLY "+str(c)+" NON-UNITS");
        return s / p;





def nondecomposable_characters(p):

        # The unique quadratic extension of F_p is F_{p^2}.
        pp = p**2;

        # Construct the field F_{p^2}
        K = GF(pp, name="g", modulus="primitive");

        # Obtain a generator for F_{p^2}
        print("waiting for generator...");
        g = K.gen();
        print("got generator");

        # We will store the nondecomposable characters as 
        # column vectors of a (p^2)x(p^2) complex matrix.
        # here 'CDF' means 'Complex Double Format'
        ch = matrix(CDF, pp);

        # TODO: Is this where things are messing up? See R+L p121 col2 parag2.
        # Do we need tr(j) rather than j?

        # For efficiency's sake, we will exponentiate this constant value. 
        char_base = complex(exp(2.0*pi*I*(1.0/(float(pp)-1.0))));

        # 1,... (p^2)-1
        for j in range(0, pp-1):
                # 1,... (p^2)-1
                for k in range(0, pp-1):
                        ch[k, j] = char_base**int((mod(j*k, pp)));


        # Remove all decomposables
        # For the logic behind this, see the brief write-up
        # by Reyes, which I will soon modify for us.
        c = 0;
        for i in range(0, pp-1):
                if mod(p*i, pp-1) == i:
                        print("is decomposable");
                        # Set column 'i' to be a vector of zeros.
                        ch[:,i] = vector([0]*pp)

                        c = c + 1;
                
        print("removed "+str(c)+" decomposables");

        return ch;

def nondecomposable_characters2(p):

        pp = p**2;

        ch = matrix(CDF, pp);

        # For efficiency's sake, we will exponentiate this constant value. 
        char_base = complex(exp(2.0*pi*I*(1.0/(float(pp)-1.0))));

        # 0,... (p^2)-2
        for x in range(0, pp-1): 
                for y in range(0, pp-1):
                        ch[x, y] = char_base**int(mod(x*y, pp-1));



        # Remove all decomposables
        # For the logic behind this, see the brief write-up
        # by Reyes, which I will soon modify for us.
        c = 0;
        for i in range(0, pp-1):
                if mod(p*i, pp-1) == i:
                        print("%d is decomposable" % (i));
                        # Set column 'i' to be a vector of zeros.
                        ch[i,:] = vector([0]*pp)

                        c = c + 1;
                
        print("removed "+str(c)+" decomposables");

        return ch;



def pow_of_gen(n, gen):
        tmp = gen;
        pwr = 1;

        while tmp != n:
            tmp = tmp * gen;
            pwr = pwr + 1;

        return pwr;

def pow_of_gen_2(n, gen, p):
        tmp = gen;
        pwr = 1;

        K = IntegerModRing(p);

        while K(tmp) != n:
            tmp = tmp * gen;
            pwr = pwr + 1;
            print(tmp);

        return pwr;



#K     = GF(3, name="kk", modulus="primitive");
#L     = GF(3**2, name="gg", modulus="primitive");
#L_gen = L.gen();
#K_gen = K.gen();

#print(pow_of_gen(L(1), L_gen));
#exit();

#for k in K:
    #if k == 0:
        #print(k, "--");
    #else:
        #print(k, pow_of_gen(k, K_gen));

#for l in L:
    #if l == 0:
        #print(l, "--");
    #else:
        #print(l, pow_of_gen(l, L_gen));

#exit();

        

def TEST_0(num, p):
    print("inverse of %d: %d\n" % (num, int(modinv(num, p))));
    print("square of inverse: %d\n" % (int(modinv(num, p)**2)));
    print("square of inverse mod %d: %d\n" % (p, int(mod(modinv(num, p)**2, p))));


#TEST_0(3, 5);
#exit();

def CHI(j):
    return 


class DiscreteSeriesRepresentation():

        def __init__(self, p, g, character):
                self.p = p; # order of field K = Z/pZ
                self.g = g; # generator for K

                self.K     = GF(p, "kk", modulus="primitive");
                self.K_gen = self.K.gen();

                self.L     = GF(self.p**2, name="gg", modulus="primitive");
                self.L_gen = self.L.gen();


                # INDEXED WITH POWER OF FIXED GENERATOR EQUALING ELEMENT
                self.char = character;

                # INDEXED WITH ACTUAL INTEGER VALUE OF ELEMENT
                self.CHI = [
                    complex(exp((2.0*pi*I*j)/self.p)) for j in range(0, self.p)
                ];

                self.W_cached = None;

        def U(self, b):
                # @b is in K^+

                R = matrix(CDF, self.p-1);

                # @x is in K^*  (1,...,p-1)
                for x in range(1, self.p):
                        R[x-1, x-1] = self.CHI[int(mod(x*b, self.p))];

                return R; 

        def T(self, a):
                R = matrix(CDF, self.p-1);

                #a_inverse = modinv(a, self.p);
                #a = self.K(a)**-2;
                #a_inv = (a**-2)*x;

                #NOT EVEN USED HERE
                #a_inv1 = self.K(a)**-2;

                #a_inv = self.K_gen ** (a_pow*-2);

                #print(a_inv1, a_inv);

                #a_pow = pow_of_gen(a, self.K_gen);
                a_2inv = self.K(a)**-2;
                a_2inv_pow = mod(pow_of_gen(a_2inv, self.K_gen), self.p - 1);
                #if a_2inv_pow == self.p-1:
                    #a_2inv_pow = 0;

                pwr2 = mod(pow_of_gen(self.L(self.K(a)**-1), self.L_gen), self.p**2 - 1); 

                for x in range(0, self.p-1): 
                        # the mod is to send p-1 -> 0
                        new_x = a_2inv_pow + x;
                        #new_x = mod(a_2inv_pow + x, self.p-1); 
                        #new_x = self.K_gen ** (x*-2)
                        #new_x = int(a_inv*x);

                        R[x, new_x] = self.char[pwr2];

                return R; 

        def jay(self, z, char, p, L_gen):
                s = 0;
                #print(self.CHI);
                for l in self.L:
                        if l.is_unit() == False:
                                continue;

                        norm = l**(p + 1);

                        if norm == z:
                                tr = l.trace();
                                #print(tr);
                                #print("pow of gen", pow_of_gen(l, L_gen));
                                #print(mod(pow_of_gen(l, L_gen), p**2 - 1));
                                s = s + self.CHI[tr] * char[mod(pow_of_gen(l, L_gen), (p**2) - 1)];

                return s / p;

        def W(self):

                if self.W_cached == None:
                    pp = self.p**2;

                    M = matrix(CDF, self.p-1);
                    J = matrix(CDF, self.p-1);

                    for y in range(0, self.p-1):
                            #ii    = pow_of_gen(i, self.L_gen);
                            #i_inv = modinv(i, pp);  

                            # WE WORK IN QUAD EXT SO USE ADDITIVE INVERSE HERE,
                            # SINCE ELEMENTS ARE ALL IMPLICITLY POWERS OF GEN
                            # ALREADY WE LOOP OVER THEM AS THESE POWERS.
                            #i_inv = self.L(self.K(i)**-1); 
                            #yy = self.K_gen**y;

                            yy = self.K_gen**y;

                            #inv = self.L(yy)**-1; 
                            inv = yy**-1;
                            #inv = self.L(yy**-1);#self.L(yy)**-1; 
                            pwr = pow_of_gen(inv, self.L_gen);

                            if pwr == pp-1:
                                pwr = 0;

                            # Must do this because for matrix niceness we send 
                            # pp-1->0...
                            #adj_pwr = mod(pwr, pp-1);

                            #print(i_inv);
                            ##print(self.L_gen);
                            #print(pow_of_gen(i_inv, self.L_gen));

                            #print(self.char[mod(pow_of_gen(i_inv, self.L_gen), pp-1)]);

                            #print(i - 1)

                            #M[i-1,i-1] = self.char[modinv(i, self.p)]; # NOTE
                            #M[i-1,i-1] = self.char[mod(pow_of_gen(i_inv, self.L_gen), pp-1)]; #pow_of_gen(i_inv, self.L_gen)]; 

                            #pwr2 = mod(pow_of_gen(y, self.K_gen), self.p-1);

                            M[y, y] = self.char[pwr]; #pow_of_gen(i_inv, self.L_gen)]; 

                    for x in range(0, self.p-1):
                            for y in range(0, self.p-1):
                                    xx = self.K_gen ** x;
                                    yy = self.K_gen ** y;

                                    z = xx*yy;

                                    #z = self.K(xx)*self.K(yy);
                                    #z = self.K(x)*self.K(y);

                                    # The mod shifts p-1 to the 0 position...
                                    #row = mod(pow_of_gen(x, self.K_gen), self.p-1);
                                    #col = mod(pow_of_gen(y, self.K_gen), self.p-1);

                                    J[x, y] = self.jay(z, self.char, self.p, self.L_gen);


                    # This is the circulant matrix we wanted (it is circulant)
                    #print("J");
                    #pretty_print(J.round(2));
                    #print("\n");

                    ## This is the diagonal matrix we wanted.
                    #print("M");
                    #print(M.round(2));
                    #print("\n");

                    #print("J*M");
                    #print((J*M).round(2));

                    self.W_cached = J*M;

                return self.W_cached; #J * M; # TODO need COB or not?




        #def jay(self, z, char, p, L_gen):
                #s = 0;
                #c = 0;
                #seen = {};
                #for n in range(0, (p**2)-1):
                        #l = L_gen**n;
                        #if l in seen:
                            #print("DUPLICATED");
                            #exit();
                        #else:
                            #seen[l] = True;

                        ## For each element of (L^*) 
                        #if l.is_unit() == False:
                                #c = c + 1;
                                #continue;

                        #norm = l**(p + 1);

                        #if norm == z:
                                ##tr  = (l**p) + l; # Another way to compute the trace 
                                ##print(tr == l.trace());
                                #tr = l.trace();

                                ## The denominator 'p' is correct (not p-1). See paper.
                                #ch = self.CHI[tr];

                                #s = s + self.CHI[tr] * char[n];

                #print("ONLY "+str(c)+" NON-UNITS");
                #return s / p;

        #def W(self):

                #pp = self.p**2;

                #M = matrix(CDF, self.p-1);
                #J = matrix(CDF, self.p-1);

                #for i in range(0, self.p-1):
                        ##ii    = pow_of_gen(i, self.L_gen);
                        ##i_inv = modinv(i, pp);  

                        ## WE WORK IN QUAD EXT SO USE ADDITIVE INVERSE HERE,
                        ## SINCE ELEMENTS ARE ALL IMPLICITLY POWERS OF GEN
                        ## ALREADY WE LOOP OVER THEM AS THESE POWERS.
                        #i_inv = mod((pp-1) - i, pp-1);

                        ##print(i_inv);
                        ##print(self.L_gen);
                        ##print(pow_of_gen(i_inv, self.L_gen));

                        ##M[i-1,i-1] = self.char[modinv(i, self.p)]; # NOTE
                        #M[i,i] = self.char[i_inv]; #pow_of_gen(i_inv, self.L_gen)]; 

                ## TODO: ALMOST THERE... JUST NEED TO ENSURE THAT JAY IS WORKING
                ## PROPERLY AND THAT THESE 2 LOOPS ARE OVER THE RIGHT
                ## RANGES
                #for x in range(1, self.p):
                        #for y in range(1, self.p):
                                #z = mod(x*y, self.p);
                                #J[x-1,y-1] = self.jay(z, self.char, self.p, self.L_gen);

                ## This is the circulant matrix we wanted (it is circulant)
                #print("J");
                #pretty_print(J.round(2));
                #print("\n");

                ## This is the diagonal matrix we wanted.
                #print("M");
                #print(M.round(2));
                #print("\n");

                #return J * M; # TODO need COB or not?

        def W_inv(self):
                # Can just invert the representation and be good? 
                # Because gp. homomorphism?
                # 
                # TODO: Check how close to being singular
                return self.W().inverse();

def rep(R, p, a, b, c, d):
    """ 
    Implements Bruhat decomposition 
    @a    :
    @b    :
    @c    :
    @d    :
    Return:
    """
    ring = IntegerModRing(p);

    a = ring(a);
    b = ring(b);
    c = ring(c);
    d = ring(d);

    #print(int(d*c**(-1)));

    if c % p == 0:
        bruhat = R.W()               \
               * R.U(int(-c*(a)**(-1)))   \
               * R.W()               \
               * R.T(int(-a))             \
               * R.U(int(b*a**(-1)));
    else:
        bruhat = R.U(int(a*c**(-1)))      \
               * R.W()               \
               * R.T(int(c))              \
               * R.U(int(d*c**(-1)));
    
    return bruhat; 


def TEST_SCHUR(R):

        p = R.p;
        W = R.W();

        ZERO = matrix(p-1);
        M1   = matrix(p-1);
        M2   = matrix(p-1);

        for t in range(1,p):
                for u in range(0,p):
                        for v in range(0,p):
                                M1 += R.T(t)*R.U(u)*W*R.U(v);

        for t in range(1,p):
                for u in range(0,p):
                        M2 += R.T(t)*R.U(u);

        # adult way would be to check their difference is < some epsilon
        return (M1 + M2).round(2) == ZERO

def TEST_W(R):
        W =  rep(R, R.p, 0, 1, -1, 0);
        Wi = rep(R, R.p, 0, -1, 1, 0);

        #print(W * Wi); # Should be identity
        return (W * Wi).round(2) == matrix.identity(R.p-1);

def TEST_THING(R):
        A  = rep(R, R.p, 1, 1, 0, 1);
        B  = rep(R, R.p, 1, -1, 0, 1);

        #print(A*B); # should be identity
        return (A*B).round(2) == matrix.identity(R.p-1);

def TEST_ORDER(R):
        A  = rep(R, R.p, 1, 1, 0, 1);
        Ap = A**R.p;

        B  = rep(R, R.p, 1, -1, 0, 1);
        Bp = B**R.p;

        #print(Ap);
        #print(Bp);

        return Ap.round(2) == Bp.round(2) == matrix.identity(R.p-1);

                            

def RUN_TESTS(p,g):

        X = nondecomposable_characters2(p);

        print(X.round(2));

        for char in X.rows():
                if char[0] == 0 and char[1] == 0 and char[2] == 0:
                    continue;

                R = DiscreteSeriesRepresentation(p, g, char);

                #for x in R.L:
                    #print(x);

                #print('--');

                #for n in range(0, (R.p*R.p) - 1):
                    #print(n, R.L_gen**n);

                #print('--');

                #R.W();
                #exit();

                #print("schur");
                #TEST_SCHUR(R);
                #print("w");
                #TEST_W(R);
                #print("order");
                #TEST_ORDER(R);
                #print("thing");
                #TEST_THING(R);
                #print("--");
                print("Schur:"+str(TEST_SCHUR(R)));
                print("W:"+str(TEST_W(R)));
                print("ORDER:"+str(TEST_ORDER(R)));
                print("THING:"+str(TEST_THING(R)));
                print("----");




#RUN_TESTS(3, 2);        
#exit();



def second_largest_eigenvalue(matrix):

        evals = matrix.eigenvalues();

        first  = complex(0);
        second = complex(0);

        for i in range(0, len(evals)):
                x = complex(evals[i]);
                if abs(x) > abs(second):
                        if abs(x) > abs(first):
                                second = first;
                                first = x;
                        else:
                                second = x;

        return second;


PRIMES = [
	3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 
	71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127
];

SMALL_PRIMES = [
	3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 
	71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127
];

SMALL_PRIMES_AND_GENERATORS = [
	(3, 2), (5, 2), (7, 3), (11, 2), (13, 2), (17, 3)#, (19, 2), (23, 5), 
	#(29, 2), (31, 3), (37, 2), (41, 6), (43, 3), (47, 5), (53, 2), (59, 2), 
	#(61, 2), (67, 2), (71, 7), (73, 5), (79, 3), (83, 2), (89, 3), (97, 5), 
	#(101, 2), (103, 5), (107, 2), (109, 6), (113, 3), (127, 3)
];

PRIMES_AND_GENERATORS = [
	(3, 2), (5, 2), (7, 3), (11, 2), (13, 2), (17, 3), (19, 2), (23, 5), 
	(29, 2), (31, 3), (37, 2), (41, 6), (43, 3), (47, 5), (53, 2), (59, 2), 
	(61, 2), (67, 2), (71, 7), (73, 5), (79, 3), (83, 2), (89, 3), (97, 5), 
	(101, 2), (103, 5), (107, 2), (109, 6), (113, 3)#, (127, 3)
];


def EXPERIMENT_spectrum_2():
	LD = [];
	LP = [];

	g1_csv = open("g1_spectrum_disc.csv", "w");

	g1_csv.write("line, p, multiplicity, evalue_scaled, evalue_real_part, evalue_imag_part\n");

	g1_line = 0;

        for p, g in SMALL_PRIMES_AND_GENERATORS:

                #if p > 3:
                    #exit();

                print("in prime:"+str(p)+" generator:"+str(g));

		chp = nondecomposable_characters2(p);

                #print(chp.round(2));

                # DISCRETE SERIES ALL eigenvalues
                for i in range(0, (p**2)-1):
		        R = DiscreteSeriesRepresentation(p, g, chp.row(i));

                        if chp.row(i)[0] == 0.0:
                            continue;

                        #print("Character:");
                        #print(chp.round(2).column(i));


			#W = R.W();
                        #exit();
                        
                        #try: 
                            #Winv = W.inverse();
                        #except ZeroDivisionError:
                            #continue;

                        
                        #continue;
			#Winv = W.inverse();

                        #g1 = r.U(1)       + r.U(p-1)     + W + Winv;
                        A = rep(R, R.p, 1, 1, 0, 1);
                        B = rep(R, R.p, 1, -1, 0, 1);
                        C = rep(R, R.p, 0, 1, -1, 0);
                        D = rep(R, R.p, 0, -1, 1, 0);

                        g1 = A + B + C + D;

                        #g2 = r.U((p+1)/2) + r.U((p-1)/2) + W + Winv;
                        
                        for evalue, e, multiplicity in g1.eigenvectors_right(): 
				g1_csv.write("%d, %d, %d, %05f, %05f, %05fi\n" % (
					g1_line, 
					p, 
					multiplicity,
					float(evalue.real())/4.0,
					evalue.real(),
					evalue.imag()
                                ));
				g1_line += 1;

EXPERIMENT_spectrum_2();
exit();
