#!/usr/bin/env sage

import sys
from sage.all import *

# GLOBAL STATE 
#------------------------------------------------------------------------------
UCF = UniversalCyclotomicField();


class CyclicCharacter():
    """
    Implements a character on a cyclic group.
    
    NOTES
    1. If C is a finite cyclic group of order m, then C is 
    isomorphic to the group of m-th roots of unity under 
    multiplication, and this isomorphism is the character.

    The primitive m-th roots of unity are the complex numbers
        e^(2*pi*i*j*(1/m))      for 1<=j<=m, gcd(j,m)=1.
    Let 
        zeta_m = e^(2*pi*i*(1/m)). 
        
    Then the m-th roots of unity are the distinct powers 
        zeta_m^j                for 1<=j<=m.

    Fix a generator <g>=C. The character must map g to 
    a primitive m-th root of unity. There are phi(m) many
    primitive m-th roots of unity, where phi() is Euler's
    totient function, giving us phi(m) distinct characters
    on C.

    Define the character 
        X_j:C-->Complex         for 1<=j<=m, gcd(j,m)=1
            g-->zeta_m^j

    Once we have defined where the generator goes, the rest
    of the elements follow by multiplication:

        X_j(u=g^k) = (zeta_m^j)^k.

    2. These facts mean that to specify a character we need
    only specify the integer order (m) of the group and the
    integer power (j) of zeta_m to which we send the fixed 
    generator of C. 
    """
    def __init__(self, order, power=1, exact=True):
        """
        Instantiate a CyclicCharacter object.
        @order: Integer specifying primitive @order-th root of unity.
        @power: Integer power of zeta_@order (selects generator/primitive RoU).
        @exact: True-Store as Cyclotomic polynomial; False-Store as Complex.
        Return: NONE

        CAUTION
        If gcd(@order, @power) != 1, then zeta_@order^@power 
        is not primitive and hence won't generate the group.
        """
        self.base = UCF.zeta(order);
        self.power = power;
        self.order = order;
        if exact == False:
            self.base = complex(self.base.real(), self.base.imag());

    def eval(self, j):
        """
        Implement the mapping u=g^j --> (self.base)^j.
        @j    : Integer power to take of the base.
        Return: Cyclotomic polynomial or Complex value (see @exact, __init__())

        """
        return self.base**int(mod(self.power*Integer(j), self.order));


def nondecomposable_characters(p):
        # The unique quadratic extension of F_p is F_{p^2}.
        pp = p**2;

        # Construct the field F_{p^2}
        L = GF(pp, name="g", modulus="primitive");

        # Obtain a generator for F_{p^2}
        print("waiting for generator...");
        g = L.gen();
        print("got generator");

        L_unit_gp_order = (p**2);

        characters = [];

        for k in range(0, pp):
            if int(mod(k*(pp+1), pp)) % p == 0:
                print("decomposable");
                print("%d %d\n" % (mod(k*(pp+1), pp), p));
            else:
                characters.append(CyclicCharacter(order=L_unit_gp_order, power=k, exact=False));

        return (characters, g);

def get_power(elem, gen):
        tmp = gen;
        count = 1;

        while tmp != elem:
            tmp   = tmp*gen;
            count = count+1;

        return count;

def jay(X, nu, z, gen):

        my_sum = 0;

        ZG = GF(p, name="g", modulus="primitive"); 
        zg = ZG.gen();

        for n in range(1, nu.order+1):
                t = gen**n;

                norm = t**(X.order + 1);

                if norm == gen**z:
                    tr = t.trace();
                    print(tr);

                    # NEED TO ADD GENERATOR FOR Z/pZ HERE TO GET POWERS RIGHT
                    # SIGHGHGHGHGHGHG

                    power_1 = mod(get_power(tr, zg), X.order);

                    my_sum += X.eval(power_1)*nu.eval(n);

                #if t*(X.order + 1) == z:
                #if t+(self.X+1) mod(t*(nu.order+1), nu.order) == z:

                        #tr  = (l**p) + l; # Another way to compute the trace 

        return (1.0/float(X.order)) * my_sum;


        #my_sum = 0;

        #for t in range(1, nu.order+1):
                #if t*(X.order + 1) == z:
                ##if t+(self.X+1) mod(t*(nu.order+1), nu.order) == z:
                        #my_sum += X.eval(t + (t**X.order))*nu.eval(t);

                        ##tr  = (l**p) + l; # Another way to compute the trace 

        #return (1.0/float(X.order)) * my_sum;

                
class DSRep():

        def __init__(self, p, g, character, gen):
                self.p = p; # order
                self.g = g; # generator

                self.char = character;
                self.gen = gen;

                self.X    = CyclicCharacter(order=p, power=1, exact=False);

        ####################################################### DISCRETE SERIES

        def U(self, u):
                M = matrix(CDF, self.p);

                for x in range(1, self.p+1):
                        M[mod(x, self.p), mod(x, self.p)] = self.char.eval(mod(x*u, self.p));

                return M; 

        def T(self, t):
                M = matrix(CDF, self.p);

                for x in range(1, self.p+1):
                        M[mod(x, self.p), mod((self.p**2)*x, self.p)] = self.char.eval(self.p-x);

                return M; 

        def W(self):
                M = matrix(CDF, self.p);

                for x in range(1, self.p+1):
                        for y in range(1, self.p+1):
                                #print(self.char.eval(self.char.order - x));
                                #print("--");
                                #print(jay(self.X, self.char, x*y));
                                #print("----");
                                #if (x == 0):
                                    #M[mod(x, self.p),mod(y, self.p)] = self.char.eval(x)*jay(self.X, self.char, x*y);
                                #else:
                                M[mod(x, self.p), mod(y,self.p)] = self.char.eval(self.char.order-x)*jay(self.X, self.char, x*y, self.gen);

                print(M);
                return M;
                    
        def W_inv(self):
		return self.W().inverse();



def second_largest_eigenvalue(matrix):

        evals = matrix.eigenvalues();

        first  = complex(0);
        second = complex(0);

        for i in range(0, len(evals)):
                x = complex(evals[i]);
                if abs(x) > abs(second):
                        if abs(x) > abs(first):
                                second = first;
                                first = x;
                        else:
                                second = x;

        return second;


def primes(n):
    """ Returns  a list of primes < n """
    sieve = [True] * n
    for i in xrange(3,int(n**0.5)+1,2):
        if sieve[i]:
            sieve[i*i::2*i]=[False]*((n-i*i-1)/(2*i)+1)
    return [2] + [i for i in xrange(3,n,2) if sieve[i]]


PRIMES = [
	3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 
	71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127
];

SMALL_PRIMES = [
	3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 
	71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127
];

SMALL_PRIMES_AND_GENERATORS = [
	(3, 2), (5, 2), (7, 3), (11, 2), (13, 2), (17, 3)#, (19, 2), (23, 5), 
	#(29, 2), (31, 3), (37, 2), (41, 6), (43, 3), (47, 5), (53, 2), (59, 2), 
	#(61, 2), (67, 2), (71, 7), (73, 5), (79, 3), (83, 2), (89, 3), (97, 5), 
	#(101, 2), (103, 5), (107, 2), (109, 6), (113, 3), (127, 3)
];

PRIMES_AND_GENERATORS = [
	(3, 2), (5, 2), (7, 3), (11, 2), (13, 2), (17, 3), (19, 2), (23, 5), 
	(29, 2), (31, 3), (37, 2), (41, 6), (43, 3), (47, 5), (53, 2), (59, 2), 
	(61, 2), (67, 2), (71, 7), (73, 5), (79, 3), (83, 2), (89, 3), (97, 5), 
	(101, 2), (103, 5), (107, 2), (109, 6), (113, 3)#, (127, 3)
];



def rep(R, p, a, b, c, d):
    """ 
    Implements Bruhat decomposition 
    @a    :
    @b    :
    @c    :
    @d    :
    Return:
    """
    ring = IntegerModRing(p);

    a = ring(a);
    b = ring(b);
    c = ring(c);
    d = ring(d);

    print(int(d*c**(-1)));

    if c % p == 0:
        bruhat = R.W()               \
               * R.U(int(-c*(a)**(-1)))   \
               * R.W()               \
               * R.T(int(-a))             \
               * R.U(int(b*a**(-1)));
    else:
        bruhat = R.U(int(a*c**(-1)))      \
               * R.W()               \
               * R.T(int(c))              \
               * R.U(int(d*c**(-1)));
    
    return bruhat; 


def EXPERIMENT_g3_disc():
	LD = [];
	LP = [];

	g3_csv = open("g3_spectrum_disc_2.csv", "w");
	g3_csv.write("line, p, multiplicity, evalue_scaled, evalue_real_part, evalue_imag_part\n");

	g3_line = 0;

        for p, g in PRIMES_AND_GENERATORS:
        #for p, g in [(3,2), (5,2), (7,3)]:

                print("in prime:"+str(p)+" generator:"+str(g));

		(chars, gen) = nondecomposable_characters(p);

                #R = DSRep(p, g, chars[1]);
                #print(R.W());
                #exit();


                # PRINCIPAL SERIES ALL eigenvalues
                for ch in chars: 
		        R = DSRep(p, g, ch, gen);

                        elem_1 = rep(R, p, 1, 1, -1, 0);
                        elem_2 = rep(R, p, 0, -1, 1, 1);
                        elem_3 = R.W();
                        elem_4 = R.W().inverse();

                        g3 = elem_1 + elem_2 + elem_3 + elem_4;
                        
                        for evalue, e, multiplicity in g3.eigenvectors_right(): 
				g3_csv.write("%d, %d, %d, %05f, %05f, %05fi\n" % (
					g3_line, 
					p, 
					multiplicity,
					float(evalue.real())/4.0,
					evalue.real(),
					evalue.imag()
                                ));
				g3_line += 1;

EXPERIMENT_g3_disc();
exit();


def EXPERIMENT_g3():
	LD = [];
	LP = [];

	g3_csv = open("g3_spectrum.csv", "w");
	g3_csv.write("line, p, multiplicity, evalue_scaled, evalue_real_part, evalue_imag_part\n");

	g3_line = 0;

        for p, g in PRIMES_AND_GENERATORS:
        #for p, g in [(3,2), (5,2), (7,3)]:

                print("in prime:"+str(p)+" generator:"+str(g));

		chp = principal_characters(p, g);

                # PRINCIPAL SERIES ALL eigenvalues
                for i in range(1, p):
		        R = PrincipalSeriesRepresentation(p, g, chp.column(i));

                        elem_1 = rep(R, p, 1, 1, -1, 0);
                        elem_2 = rep(R, p, 0, -1, 1, 1);
                        elem_3 = R.W();
                        elem_4 = R.W().inverse();

                        g3 = elem_1 + elem_2 + elem_3 + elem_4;
                        
                        for evalue, e, multiplicity in g3.eigenvectors_right(): 
				g3_csv.write("%d, %d, %d, %05f, %05f, %05fi\n" % (
					g3_line, 
					p, 
					multiplicity,
					float(evalue.real())/4.0,
					evalue.real(),
					evalue.imag()
                                ));
				g3_line += 1;

EXPERIMENT_g3();
exit();


#chd = nondecomposable_characters(13);
#exit();

def EXPERIMENT_random_spectrum():

	csv = open("random_spectrum3.csv", "w");

	csv.write("line, p, multiplicity, evalue_scaled, evalue_real_part, evalue_imag_part\n");

	line = 0;

        for p, g in PRIMES_AND_GENERATORS:

                if p <= 11:
                        continue;

                print("in prime:"+str(p)+" generator:"+str(g));

		chp = principal_characters(p, g);

                # PRINCIPAL SERIES ALL eigenvalues
                for i in range(1, p):
		        r = PrincipalSeriesRepresentation(p, g, chp.column(i));

                        m = r.T(11)*r.U(7);

                        for evalue, e, multiplicity in m.eigenvectors_right(): 
				csv.write("%d, %d, %d, %05f, %05f, %05fi\n" % (
					line, 
					p, 
					multiplicity,
					float(evalue.real())/4.0,
					evalue.real(),
					evalue.imag()
                                ));
				line += 1;

EXPERIMENT_random_spectrum();
exit();


def EXPERIMENT_sle_growth_princ():

        csv = open("sle_growth_princ.csv", "w");

        csv.write("line, p, evalue_scaled, evalue_real_part, evalue_imag_part\n");

        line = 0;

        for p, g in PRIMES_AND_GENERATORS:

                print("in prime:"+str(p)+" generator:"+str(g));

		ch = principal_characters(p, g);

                best = 0;



                # PRINCIPAL SERIES
                for i in range(1, p):
		        r = PrincipalSeriesRepresentation(p, g, ch.column(i));

                        m = r.U(1)+r.U(p-1)+r.W()+r.W().inverse();
                        
                        ev = second_largest_eigenvalue(m);

                        if abs(ev) > abs(best):
                                best = ev;

                csv.write("%d, %d, %05f, %05f, %05f\n" % (
                        line, 
                        p, 
                        abs(best.real/4.0),
                        best.real,
                        best.imag
                ));

                line += 1;


EXPERIMENT_sle_growth_princ();
exit();

def EXPERIMENT_sle_growth_disc():

        for p, g in SMALL_PRIMES_AND_GENERATORS:

                print("in prime:"+str(p)+" generator:"+str(g));

		ch = nondecomposable_characters(p);

                best = 0;

	        csv = open("sle_growth_disc.csv", "w");

	        csv.write("line, p, evalue_scaled, evalue_real_part, evalue_imag_part\n");

                line = 0;

                # DISCRETE SERIES
                for i in range(1, p):
		        r = DiscreteSeriesRepresentation(p, g, ch.column(i));

                        m = r.U(1)+r.U(p-1)+r.W()+r.W().inverse();
                        
                        ev = second_largest_eigenvalue(m);

                        if abs(ev) > abs(best):
                                best = ev;

                csv.write("%d, %d, %05f, %05f, %05fi\n" % (
                        line, 
                        p, 
                        float(abs(best.real))/4.0,
                        best.real,
                        best.imag
                ));

                line += 1;

EXPERIMENT_sle_growth_disc();
exit();


def EXPERIMENT_spectrum_2():
	LD = [];
	LP = [];

	g1_csv = open("g1_spectrum_disc.csv", "w");

	g1_csv.write("line, p, multiplicity, evalue_scaled, evalue_real_part, evalue_imag_part\n");

	g1_line = 0;

        for p, g in SMALL_PRIMES_AND_GENERATORS:

                print("in prime:"+str(p)+" generator:"+str(g));

		chp = nondecomposable_characters(p);

                # DISCRETE SERIES ALL eigenvalues
                for i in range(1, p):
		        r = DiscreteSeriesRepresentation(p, g, chp.column(i));

			W    = r.W();
			Winv = W.inverse();

                        g1 = r.U(1)       + r.U(p-1)     + W + Winv;
                        #g2 = r.U((p+1)/2) + r.U((p-1)/2) + W + Winv;
                        
                        for evalue, e, multiplicity in g1.eigenvectors_right(): 
				g1_csv.write("%d, %d, %d, %05f, %05f, %05fi\n" % (
					g1_line, 
					p, 
					multiplicity,
					float(evalue.real())/4.0,
					evalue.real(),
					evalue.imag()
                                ));
				g1_line += 1;

EXPERIMENT_spectrum_2();
exit();



def EXPERIMENT_spectrum_1():
	LD = [];
	LP = [];

	g1_csv = open("g1_spectrum.csv", "w");
	g2_csv = open("g2_spectrum.csv", "w");

	g1_csv.write("line, p, multiplicity, evalue_scaled, evalue_real_part, evalue_imag_part\n");
	g2_csv.write("line, p, multiplicity, evalue_scaled, evalue_real_part, evalue_imag_part\n");

	g1_line = 0;
	g2_line = 0;

        for p, g in PRIMES_AND_GENERATORS:

                print("in prime:"+str(p)+" generator:"+str(g));

		chp = principal_characters(p, g);

                # PRINCIPAL SERIES ALL eigenvalues
                for i in range(1, p):
		        r = PrincipalSeriesRepresentation(p, g, chp.column(i));

			W    = r.W();
			Winv = W.inverse();

                        g1 = r.U(1)       + r.U(p-1)     + W + Winv;
                        g2 = r.U((p+1)/2) + r.U((p-1)/2) + W + Winv;
                        
                        for evalue, e, multiplicity in g1.eigenvectors_right(): 
				g1_csv.write("%d, %d, %d, %05f, %05f, %05fi\n" % (
					g1_line, 
					p, 
					multiplicity,
					float(evalue.real())/4.0,
					evalue.real(),
					evalue.imag()
                                ));
				g1_line += 1;

                        for evalue, e, multiplicity in g2.eigenvectors_right(): 
				g2_csv.write("%d, %d, %d, %05f, %05f, %05fi\n" % (
					g2_line, 
					p, 
					multiplicity,
					float(evalue.real())/4.0,
					evalue.real(),
					evalue.imag()
                                ));
				g2_line += 1;
#EXPERIMENT_spectrum_1();
#exit();
		

def EXPERIMENT_QUA3():

	LD = [];
	LP = [];

        for p in [3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97]:

		k = GF(p, modulus="primitive");
		g = int(k.gen());
                print("in prime:"+str(p)+" generator:"+str(g));

		chp = principal_characters(p, g);
		#chd = nondecomposable_characters(p);

                # PRINCIPAL SERIES second largest eigenvalues
                #for i in range(1, p):
			#r = PrincipalSeriesRepresentation(p, g, chp.column(i));

                        #m = r.U(1)+r.U(p-1)+r.W() + r.W().inverse();
                        
                        #ev = second_largest_eigenvalue(m);

                        #LP.append((float(abs(ev))/4.0, p));

                # PRINCIPAL SERIES ALL eigenvalues
                for i in range(1, p):
		        r = PrincipalSeriesRepresentation(p, g, chp.column(i));

                        #m = r.U(1)+r.U(p-1)+r.W() + r.W().inverse();
                        m = r.U((p+1)/2)+r.U((p-1)/2)+r.W() + r.W().inverse();
                        
                        for ev in m.eigenvalues(): 
                                LP.append((float(ev.real())/4.0, p));

		
	GP = list_plot(LP);
	GP.save("spectrum_cayley_g2_princ_all.pdf");

#EXPERIMENT_QUA3();
#exit();

def EXPERIMENT_QUA2():

	L  = [];
	LD = [];
	L2 = [];

        for p in [3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97]:

		k = GF(p, modulus="primitive");
		g = int(k.gen());
                print("in prime:"+str(p)+" generator:"+str(g));

		ch  = principal_characters(p, g);
		#chd = nondecomposable_characters(p);

                best = 0;
                bestd= 0;

                # PRINCIPAL SERIES
                for i in range(1, p):
		        r = PrincipalSeriesRepresentation(p, g, ch.column(i));

                        m = r.U(1)+r.U(p-1)+r.W() + r.W().inverse();
                        
                        ev = second_largest_eigenvalue(m);

                        if abs(ev) > abs(best):
                                best = ev;

                # DISCRETE SERIES
                #for i in range(1, p):
			#r = DiscreteSeriesRepresentation(p, g, chd.column(i));

                        #m = r.U2(1)+r.U2(p-1)+r.W2() + r.W2().inverse();
                        
                        #ev = second_largest_eigenvalue(m);

                        #if abs(ev) > abs(bestd):
                                #bestd = ev;

                #LD.append(abs(bestd));
                L2.append(float(abs(best))/4.0);

		
	G = list_plot(L2);
	G.save("basis_g1_secondlargest_track_princ.pdf");

	#G2 = list_plot(LD);
	#G2.save("basis_g1_secondlargest_disc.pdf");

EXPERIMENT_QUA2();
exit();

def EXPERIMENT_QUA():

	L = [];
	L2 = [];

        #for p in primes(100):
        for p in range(7,8):
		k = GF(p, modulus="primitive");
		g = int(k.gen());

		ch = principal_characters(p, g);

                # TUwU part
                for t in range(1, p):
                        for u in range(0, p):
                                # Character values determine reps
                                for i in range(1, p):
                                        print(str(t)+":"+str(u)+":"+str(i));
		                        r = PrincipalSeriesRepresentation(p, g, ch.column(i));
                                        s = r.T(t)*r.U(u)*r.W()*r.U(u);

                                        ev = second_largest_eigenvalue(s);

		                        L.append(ev);
		                        L2.append(abs(ev));

                # TU part
                for t in range(1, p):
                        for u in range(0, p):
                                # Character values determine reps
                                for i in range(1, p):
                                        print(str(t)+":"+str(u)+":"+str(i));
		                        r = PrincipalSeriesRepresentation(p, g, ch.column(i));
                                        s = r.T(t)*r.U(u);

                                        ev = second_largest_eigenvalue(s);

		                        L.append(ev);
		                        L2.append(abs(ev));

		
	G = list_plot(L);
	G.save("thinger.pdf", xmin=-1.1, ymin=-1.1, xmax=1.1, ymax=1.1);

	G2 = list_plot(L2);
	G2.save("thinger2.pdf");

EXPERIMENT_QUA();
exit();


def EXPERIMENT_1():

	L = [];
	L2 = [];

        for p in primes(100):
		k = GF(p, modulus="primitive");
		g = int(k.gen());

		ch = principal_characters(p, g);

		#for u in range(1, p):
		# ONE IS AS GOOD AS ANY OTHER I SUPPOSE - EVALUES DONT CHANGE
		# BASED ON WHAT CHARACTER IS CHOSEN.
		r  = PrincipalSeriesRepresentation(p, g, ch.column(1));

		# Generating set
		a = r.U(1);
		b = r.U(mod(-1, p));
		w    = r.W();
		winv = r.W_inv();

		L.append(second_largest_eigenvalue(a));
		L.append(second_largest_eigenvalue(b));
		L.append(second_largest_eigenvalue(w));
		L.append(second_largest_eigenvalue(winv));

		L2.append(abs(second_largest_eigenvalue(a)));

		
	G = list_plot(L);
	G.save("thinger.pdf", xmin=-1.1, ymin=-1.1, xmax=1.1, ymax=1.1);

	G2 = list_plot(L2);
	G2.save("thinger2.pdf");

EXPERIMENT_1();
exit();


def TEST_PRINC_U():
        p = 7;
        g = 3;

	ch = principal_characters(p, g);

        r = PrincipalSeriesRepresentation(p, g, ch.column(1));

        A = matrix(p+1);

        for k in range(0, p):
                a = r.U(k);
                A += a;

        print(A);

def TEST_PRINC_T():
        p = 7;
        g = 3;

	ch = principal_characters(p, g);

        r = PrincipalSeriesRepresentation(p, g, ch.column(1));

        for a in range(1, p):
                t = r.T(a);
                print(t.round(2));
                print("\n");

def TEST_PRINC_W():
        p = 7;
        g = 3;

	ch = principal_characters(p, g);

        r = PrincipalSeriesRepresentation(p, g, ch.column(1));

        print(r.W().round(2));
        print("\n");
        print(r.W_inv().round(2));
        print("\n");


def SCHUR_CHECK():
        p = 7;
        g = 3;

	ch = principal_characters(p, g);
        r = PrincipalSeriesRepresentation(p, g, ch.column(2));

        rw = r.W();

        M1 = matrix(p+1, p+1);
        M2 = matrix(p+1, p+1);

        for t in range(1,p):
                for u in range(0,p):
                        for v in range(0,p):
                                M1 += r.T(t)*r.U(u)*rw*r.U(v);

        for t in range(1,p):
                for u in range(0,p):
                        M2 += r.T(t)*r.U(u);

        print((M1 + M2).round(2));
        # Should be all 0's

                                
SCHUR_CHECK();           
exit();


def TEST_HOMOMORPHISM():
        p = 7;
        g = 3;

	ch = principal_characters(p, g);

        r = PrincipalSeriesRepresentation(p, g, ch.column(1));

        ############################# U HOMOMORPHISM

        U1 = matrix(2,2);
        U1[0,0] = 1;
        U1[0,1] = 2;
        U1[1,0] = 1;
        U1[1,1] = 0;

        U2 = matrix(2,2);
        U1[0,0] = 1;
        U1[0,1] = 4;
        U1[1,0] = 1;
        U1[1,1] = 0;

        ua = r.U(2);
        ub = r.U(4);

        q = ua*ub;

        z = r.U(6);
        print(ua*ub);
        print("\n");
        print(z);
        print("\n");
        print(ua * ub == z);

        ############################# T HOMOMORPHISM

        T1 = matrix(2,2);
        T1[0,0] = 2;
        T1[0,1] = 0;
        T1[1,0] = -2;
        T1[1,1] = 0;

        T2 = matrix(2,2);
        T2[0,0] = 4;
        T2[0,1] = 0;
        T2[1,0] = -4;
        T2[1,1] = 0;

        ta = r.T(2);
        tb = r.T(4);

        q = ta*tb;

        z = r.T(1);
        print((ta*tb).round(5));
        print("\n");
        print(z);
        print("\n");
        print((ta * tb).round(5) == z);

        ############################# W HOMOMORPHISM (??)

         



#TEST_HOMOMORPHISM();
#exit();
#TEST_PRINC_U();
TEST_PRINC_T();
#TEST_PRINC_W();
exit();


#def EXPERIMENT_2(p):

            #k = GF(p, modulus="primitive");
            #g = int(k.gen());

            #print(p, g);

	    #ch = principal_characters(p, g);

            #for j in range(1, 2):
                #r = PrincipalSeriesRepresentation(p, g, ch.column(j));

                ##print(ch.round(2));

                #A = matrix(p+1);

                #for k in range(0, p):
                    #a = r.U(k);
                    #A += a;

                    ##print("\n");
                    ##print(a.round(2));
                    ##print("\n");

                #print(A);



	    # Generating set
            #a = r.U(1);
            #a = r.T(1);
            ##b = r.U(mod(-1, p));
            ##w    = r.W();
            ##winv = r.W_inv();

            #print("\n");
            #print(a.round(2));
            #print("\n");
            #print(b.round(2));
            #print("\n");
            #print(w.round(2));
            #print("\n");
            #print(winv.round(2));

EXPERIMENT_2(7);
exit();



def experiment(p, g):

        for j in range(1, p):
                print("\nseries "+str(j));
                for k in range(1, p):

                        val = mod(g**k, p);

                        # These floats are necessary in Python 2.7 in order
                        # to make the division be non-truncating. This was
                        # fixed in Python 3.x
                        res = complex(exp(2.0*pi*I*float(j)*(float(k)/float(p-1))));

                        res = complex(round(res.real, 10), round(res.imag, 10));

                        print(val, res, res*res);

experiment(7,3);
exit();





ch = nondecomposable_characters(7);
r = DiscreteSeriesRepresentation(7, 3, ch.column(1));

m = r.T(2);
print(m.round(2));

exit();


EXPERIMENT_1();
exit();



ch = principal_characters(7,3);

r = PrincipalSeriesRepresentation(7, 3, ch.column(1));
m = r.U(3);

print(m.round(2));
print("\n");

exit();



print(ch.ncols());



exit();

#exit();

for i in range(1,7):
        r = PrincipalSeriesRepresentation(7, 3, ch);
        m = r.T(i);
        print(m.eigenvalues());
        print("\n");

exit();


r = PrincipalSeriesRepresentation(7, 3, chi_1);

R3 = r.T(3);

print(R3);

                
#cob = get_disc_series_cob(7,3);
#R3 = disc_rep_T(cob, 7, 3);
#R2 = disc_rep_T(cob, 7, 2);
#R6 = disc_rep_T(cob, 7, 6);
#print(R3.round(2));
#print("\n");
#print(R2.round(2));
#print("\n");
#print((R3*R2).round(2));
#print("\n");
#print(R6.round(2));
#print("\n");
