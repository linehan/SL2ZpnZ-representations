#!/usr/bin/env sage

import sys
from sage.all import *

# Representations of SL(2,Z/p^nZ)
# For our variables we shall use p = prime, n = power of the prime, D = Delta, k = integer
# Recall that 0 \leq k \leq n-1
p = 3
n = 2
k = 1
D = 5

Rn   = Integers(p^n)
Rn_k = Integers(p^(n-k))
G    = [(a,b) for a in Rn for b in Rn_k ]

def norm(u):
        U = ZZ(u[0])^2 + p^k*D*ZZ(u[1])^2 
        return Rn(U)  
    
def trace(u):
        U = 2*ZZ(u[0]) 
        return Rn(U)  

def mult(u,v):
        U1 = ZZ(u[0])*ZZ(v[0]) - p^k*D*ZZ(u[1])*ZZ(v[1])
        U2 = ZZ(u[0])*ZZ(v[1]) + ZZ(u[1])*ZZ(v[0])
        U = (Rn(U1),Rn_k(U2))
        return U


# Description: Here I assume C is a cyclic group C = <c> with order K = |C|. 
# Every character is given by c -> e^(2pi*i*m/K) for m in Z/KZ. The program 
# returns the values for m that generate primitive characters.
# Finding generator <c> = C
C = [ i for i in G if norm(i) == 1 ]
K = len(C)
R0 = Integers(K)

def ord(i):
        t = i
        order = 1
        while t != (Rn(1),Rn_k(0)):
                t = mult(t,i)
                order = order + 1
        return order

def gen(C):
        t = 0
        while ord(C[t]) != K:
                t = t+1
        return C[t]

c = gen(C)
# This is the subgroup C_n-1
R1 = Integers(p^(n-1))
R2 = Integers(p^(n-1-k)) 
CL = [i for i in C if R1(i[0]) == R1(1) and R2(i[1]) == R2(0)]

# Testing if character is primitive
def characterList(chi,A):
# Takes a character chi and a group G and returns a list with [chi(g),g]
        P = []
        for i in A:
                t = c
                a = R0(chi)
                while t != i:
                        t = mult(t,c)
                        a = a + chi
                P.append((i,a))
        return P
    

char_prim = []

for j in R0:
        B = characterList(j,CL)
        if all( b[1] == 0 for b in B) == False:
                char_prim.append(j)

print char_prim

# Finding the orbit space for the representation. For this pick any primitive character chi generated above
chi = 5

# Returns orbits without any dependence on character
def orbits(G):
        T = G
        orbits = [ ]
        while len(T) != 0:
                k = T[0]
                orb_k = []
                for c in C:
                        P = mult(k,c)
                        if P not in orb_k:
                                orb_k.append(P)

        orbits.append([orb_k[0], len(orb_k)])
        T0 = [t for t in T if t not in orb_k]
        T = T0 
    return orbits
    

# Returns orbits with dependence on characters
def orbits_char(G):
        T = G
        orbitschar = [ ]

        while len(T) != 0:
                k = T[0]
                orb_k1 = []
                orb_k2 = []
                for c in C:
                        P = mult(k,c)
                        if P not in orb_k1:
                                orb_k1.append(P)
                for c in characterList(chi,C):
                        P = mult(k,c[0])
                        if (P,c[1]) not in orb_k2:
                                orb_k2.append((P,c[1]))
                if len(orb_k1) == len(orb_k2):
                        orbitschar.append([orb_k1[0], len(orb_k1)])
                uT0 = [t for t in T if t not in orb_k1]
                T = T0 
    
        return orbitschar

orbits_char(G)

# Under construction, ignore
#Representations
#S = SL(2,Rn)

##Bruhat matrices/Decomposition
#def diag(a):
    #A = S([[a,0],[0,a^{-1}]])
    #return A

#def uptri(b):
    #A = S([[1,b],[0,1]])
    #return A

#w = S([[0,-1],[1,0]])
#def Decomp(A):
    #AG = A.list()
    
    #if AG[1][0] == 0:
        #B = w*uptri(-AG[1][0]*(AG[0][0])^{-1})*w*diag(-AG[0][0])*uptri(AG[0][1]*AG[0][0]-1)
    #else:
        #B = uptri(AG[0][0]*AG[1][0]-1)*w*diag(AG[1][0])*uptri(AG[1][1]*AG[1][0]-1)
    #return B


#def subset(a):
    #H = [(Rn(1),Rn_k(0))]
    #k = a
    #while k != (Rn(1),Rn_k(0)):
        #H.append(k)
        #k = mult(a,k)
    #return H

#def intersect(A,B):
    #T = [a for a in A if a in B]
    #return T

#def gen(A):
    #gens = []
    #G0 = [(Rn(1),Rn_k(0))]
    #t = A
    #while len(t) != 0:
        #m = max(ord(a) for a in A)
        #Bm = [a for a in A if ord(a) == m]
        #Ha = [subset(b) for b in Bm ]
        #Hg = next(h in Ha if intersect(G0,h) == [(Rn(1),Rn_k(0))])
        #G0 = [mult(a,h) for a in G0 and h in Hg]
        #gens.append([Hg[1],m])
    #return gens
                        

#gen(C)

