#!/usr/bin/env sage

"""
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 FOR WHERE YOU LEFT OFF, SEE LINE #120
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
"""

import sys
from sage.all import *

class CyclicCharacter():
    """
    Implements a character on a cyclic group.
    
    NOTES
    1. If C is a finite cyclic group of order m, then C is 
    isomorphic to the group of m-th roots of unity under 
    multiplication, and this isomorphism is the character.

    The primitive m-th roots of unity are the complex numbers
        e^(2*pi*i*j*(1/m))      for 1<=j<=m, gcd(j,m)=1.
    Let 
        zeta_m = e^(2*pi*i*(1/m)). 
        
    Then the m-th roots of unity are the distinct powers 
        zeta_m^j                for 1<=j<=m.

    Fix a generator <g>=C. The character must map g to 
    a primitive m-th root of unity. There are phi(m) many
    primitive m-th roots of unity, where phi() is Euler's
    totient function, giving us phi(m) distinct characters
    on C.

    Define the character 
        X_j:C-->Complex         for 1<=j<=m, gcd(j,m)=1
            g-->zeta_m^j

    Once we have defined where the generator goes, the rest
    of the elements follow by multiplication:

        X_j(u=g^k) = (zeta_m^j)^k.

    2. These facts mean that to specify a character we need
    only specify the integer order (m) of the group and the
    integer power (j) of zeta_m to which we send the fixed 
    generator of C. 
    """
    def __init__(self, order, power=1, exact=True):
        """
        Instantiate a CyclicCharacter object.
        @order: Integer specifying primitive @order-th root of unity.
        @power: Integer power of zeta_@order (selects generator/primitive RoU).
        @exact: True-Store as Cyclotomic polynomial; False-Store as Complex.
        Return: NONE

        CAUTION
        If gcd(@order, @power) != 1, then zeta_@order^@power 
        is not primitive and hence won't generate the group.
        """
        self.base_exact   = UniversalCyclotomicField().zeta(order);
        self.base_complex = complex(self.base_exact.real(), self.base_exact.imag());
        self.power        = power;
        self.order        = order;
        self.exact        = exact;

    def eval(self, j, exact=None):
        """
        Implement the mapping u=g^j --> (self.base)^j.
        @j    : Integer power to take of the base.
        @exact: Boolean; True gives elem. of UCF, False gives complex number
        Return: Cyclotomic polynomial or Complex value (see @exact, __init__())

        """
        if exact == True or self.exact == True: 
            return self.base_exact ** mod(self.power*Integer(j), self.order);
        elif exact == False or self.exact == False:
            return self.base_complex ** mod(self.power*Integer(j), self.order);

    def __getitem__(self, j):
        return self.eval(j);

def nondecomposable_characters(p):

        pp = p**2;

        ch = matrix(CDF, pp-1);

        # For efficiency's sake, we will exponentiate this constant value. 
        char_base = complex(exp(2.0*pi*I/(pp-1)));

        # 0,... (p^2)-2
        for x in range(0, pp-1): 
                for y in range(0, pp-1):
                        ch[x, y] = char_base**int(mod(x*y, pp-1));


        # Remove all decomposables
        # For the logic behind this, see the brief write-up
        # by Reyes, which I will soon modify for us.
        c = 0;
        for i in range(0, pp-1):
                if mod(p*i, pp-1) == i:
                        print("%d is decomposable" % (i));
                        # Set row 'i' to be a vector of zeros.
                        ch[i,:] = vector([0]*(pp-1));

                        c = c + 1;

        # MAYBE WE HAVE TOO MANY CHARACTERS STILL? cf. p.122 ?

        print("removed "+str(c)+" decomposables");

        return ch;

"""
TODO: We are working on making this use the UCF like in the Tanaka portion.
We need to make the various functions U(), T(), W() work with this...

THAT IS WHERE THIS STANDS
"""
def nondecomposable_characters_ucf(p):

        pp = p**2;

        #ch = matrix(pp-1);

        X_list = [None for x in range(0, pp-1)];

        c = 0;

        # 0,... (p^2)-2
        for x in range(0, pp-1):
                if mod(p*x, pp-1) == x:
                    X_list[x]=[0 for i in range(0, pp-1)];
                else:
                    X_list[x]=CyclicCharacter(order=pp-1, power=x, exact=True);
                    c = c + 1;

        ## Remove all decomposables
        ## For the logic behind this, see the brief write-up
        ## by Reyes, which I will soon modify for us.
        #c = 0;
        #for x in range(0, pp-1):
                #if mod(p*i, pp-1) == i:
                        #print("%d is decomposable" % (i));
                        ## Set row 'i' to be a vector of zeros.
                        #ch[i,:] = vector([0]*(pp-1));

                        #c = c + 1;

        # MAYBE WE HAVE TOO MANY CHARACTERS STILL? cf. p.122 ?

        print("removed "+str(c)+" decomposables");

        return X_list;

def nondecomposable_characters_int(p):

        pp = p**2;

        ch = matrix(pp-1);

        # For efficiency's sake, we will exponentiate this constant value. 
        char_base = complex(exp(2.0*pi*I/(pp-1)));

        # 0,... (p^2)-2
        for x in range(0, pp-1): 
                for y in range(0, pp-1):
                        ch[x, y] = int(mod(x*y, pp-1));


        # Remove all decomposables
        # For the logic behind this, see the brief write-up
        # by Reyes, which I will soon modify for us.
        c = 0;
        for i in range(0, pp-1):
                if mod(p*i, pp-1) == i:
                        print("%d is decomposable" % (i));
                        # Set row 'i' to be a vector of zeros.
                        ch[i,:] = vector([0]*(pp-1));

                        c = c + 1;

        # MAYBE WE HAVE TOO MANY CHARACTERS STILL? cf. p.122 ?

        print("removed "+str(c)+" decomposables");

        return ch;


def pow_of_gen(n, gen):
        tmp = gen;
        pwr = 1;

        while tmp != n:
            tmp = tmp * gen;
            pwr = pwr + 1;

        return pwr;


def TEE(p):

        pp = p**2;
        s  = 0;

        K     = GF(p, name="kgen", modulus="primitive");
        K_gen = K.gen();

        L     = GF(p**2, name="ggen", modulus="primitive");
        L_gen = L.gen();

        for pwr in range(0, p-1):
                # THESE SHOULD BE EQUAL... THERE SHOULD BE NO PROBLEM
                # OF ANY KIND HERE...
                a = mod(pow_of_gen(K_gen**(-1*pwr), L_gen), pp-1);
                b = mod(pow_of_gen(L(K_gen**pwr)**-1, L_gen), pp-1);

                print(a, b);

        #for pwr in range(0, pp-1):
                #l = L_gen ** pwr; 

                #norm = l**(p + 1);

                #print(pwr, norm, l.trace());

#TEE(3);
#exit();


class DiscreteSeriesRepresentation():

        #def __init__(self, p, g, character):
                #self.p = p; # order of field K = Z/pZ
                #self.g = g; # generator for K

                #self.K     = GF(p, "kgen", modulus="primitive");
                #self.K_gen = self.K.gen();

                #self.L     = GF(self.p**2, name="ggen", modulus="primitive");
                #self.L_gen = self.L.gen();

                ## INDEXED WITH POWER OF FIXED GENERATOR EQUALING ELEMENT
                #self.L_char = character;

                ## INDEXED WITH ACTUAL INTEGER VALUE OF ELEMENT (character on K+)
                #self.K_char = [];
                #for j in range(0, self.p):
                        #self.K_char.append(complex(exp((2.0*pi*I*j)/self.p)));

                #self.W_cached = None;


        """
        IMPORTANT QUESTION:
            The matrices are elements of the field, so when we do the
            matrix multiplication etc., are we actually doing these
            computations in the correct manner?

            I.e. they are not modded around, they are just multiplied.
            This could perhaps account for the trouble I think... the
            elements of these matrices need to continue belonging to a
            finite field even after the matrices are instantiated...

            So for example in rep(), we need a way to get the matrices
            without them being simple complex numbers, and then go on
            and make them what they are after the matrix ops are complete...
            is this right? or not?

            Because we are mapping SL2(Z/nZ) -> another vector space.
            So no, when we do ops with the representations, the elements
            are not modular, we use the fact that the circle formula is
            periodic to capture that.

            Okay...
        """

        def __init__(self, p, g, character):
                self.p = p; # order of field K = Z/pZ
                self.g = g; # generator for K

                self.K     = GF(p, "kgen", modulus="primitive");
                self.K_gen = self.K.gen();

                self.L     = GF(self.p**2, name="ggen", modulus="primitive");
                self.L_gen = self.L.gen();

                # INDEXED WITH POWER OF FIXED GENERATOR EQUALING ELEMENT
                self.L_char = character;


                # INDEXED WITH ACTUAL INTEGER VALUE OF ELEMENT (character on K+)
                self.K_char = CyclicCharacter(order=self.p, power=1, exact=True); #[j for j in range(0, self.p)];

                self.W_cached = None;

        #def U(self, b):
                ## @b is in K^+

                #R = matrix(CDF, self.p-1);

                ## @x is in K^*  
                #for pwr in range(0, self.p-1):
                        #elem = self.K(b)*(self.K_gen**pwr)
                        
                        #R[pwr, pwr] = self.K_char[elem]; 

                #return R; 

        #def T(self, a):
                #R = matrix(CDF, self.p-1);

                #a_inv  = self.K(a)**-1;
                #a2_inv = self.K(a)**-2;

                #a_inv_pwr  = int(mod(pow_of_gen(self.L(a_inv), self.L_gen), (self.p**2)-1));
                #a2_inv_pwr = int(mod(pow_of_gen(a2_inv, self.K_gen), self.p-1));

                #for pwr in range(0, self.p-1): 
                        #new_pwr = mod(a2_inv_pwr+pwr, self.p-1);

                        #R[pwr, new_pwr] = self.L_char_base ** self.L_char[a_inv_pwr];

                #return R; 

        #def W(self):
                #def jay(z, p, L, L_gen, L_char, K_char):

                        #pp = p**2;
                        #s  = 0;

                        #for pwr in range(0, pp-1):
                                #l = L_gen ** pwr; 

                                #norm = l**(p + 1);

                                #if norm == z:
                                        #tr = l.trace();
                                        #s = s + (K_char[tr] * L_char[pwr]);

                        #return s / p;


                #if self.W_cached == None:

                    ##pp = self.p**2;
                    ##M = matrix(CDF, self.p-1);
                    ##J = matrix(CDF, self.p-1);

                    ##for pwr_y in range(0, self.p-1):
                            ##y = self.K_gen ** pwr_y;

                            ##y_Lpow = int(mod(pow_of_gen(y, self.L_gen), pp-1));

                            ##M[pwr_y, pwr_y] = self.L_char[y_Lpow]**-1;

                    ##for pwr_x in range(0, self.p-1):
                            ##for pwr_y in range(0, self.p-1):
                                    ##x = self.K_gen ** pwr_x;
                                    ##y = self.K_gen ** pwr_y;
                                    ##z = self.K(x)*self.K(y);

                                    ##J[pwr_x, pwr_y] = jay(z, self.p, self.L, self.L_gen, self.L_char, self.K_char);


                    #pp = self.p**2;
                    #R = matrix(CDF, self.p-1);

                    #for pwr_x in range(0, self.p-1):
                            #x          = self.K_gen ** pwr_x;
                            #pwr_x_in_L = int(mod(pow_of_gen(x, self.L_gen), self.p**2 - 1));
                            #L_char_val = self.L_char[pwr_x_in_L]**-1; 

                            #for pwr_y in range(0, self.p-1):
                                    #y = self.K_gen ** pwr_y;
                                    #z = self.K(x)*self.K(y);

                                    #R[pwr_y, pwr_x] = L_char_val * jay(z, self.p, self.L, self.L_gen, self.L_char, self.K_char);

                                


                    ## This is the circulant matrix we wanted (it is circulant)
                    ##print("J");
                    ##pretty_print(R.round(2));
                    ##print("\n");

                    ### This is the diagonal matrix we wanted.
                    ##print("M");
                    ##print(M.round(2));
                    ##print("\n");

                    ##print("J*M");
                    ##print((J*M).round(2));
                    ##print("R");
                    ##print(R.round(2));
                    ##print(complex(round(R.trace().real_part()),round(R.trace().imag_part())));

                    ##self.W_cached = J*M;
                    #self.W_cached = R;
                    ##R;

                #return self.W_cached; #J * M; # TODO need COB or not?

        def U(self, b):
                # @b is in K^+

                R = matrix(self.p-1);

                # @x is in K^*  
                for pwr in range(0, self.p-1):
                        elem = self.K(b)*(self.K_gen**pwr)
                        
                        R[pwr, pwr] = self.K_char[elem]; 

                return R; 


        def T(self, a):
                R = matrix(CDF, self.p-1);

                a_inv  = self.K(a)**-1;
                a2_inv = self.K(a)**-2;

                a_inv_pwr  = int(mod(pow_of_gen(self.L(a_inv), self.L_gen), (self.p**2)-1));
                a2_inv_pwr = int(mod(pow_of_gen(a2_inv, self.K_gen), self.p-1));

                for pwr in range(0, self.p-1): 
                        new_pwr = mod(a2_inv_pwr+pwr, self.p-1);

                        R[pwr, new_pwr] = self.L_char[a_inv_pwr];

                return R; 

        def W(self):
                def jay(z, p, L, L_gen, L_char, K_char):

                        pp = p**2;
                        s  = 0;

                        for pwr in range(0, pp-1):
                                l = L_gen ** pwr; 

                                norm = l**(p + 1);

                                if norm == z:
                                        tr = l.trace();
                                        s = s + (K_char[tr] * L_char[pwr]);

                        return s / p;


                if self.W_cached == None:

                    pp = self.p**2;
                    R = matrix(CDF, self.p-1);

                    for pwr_x in range(0, self.p-1):
                            x          = self.K_gen ** pwr_x;
                            pwr_x_in_L = int(mod(pow_of_gen(x, self.L_gen), self.p**2 - 1));
                            L_char_val = self.L_char[pwr_x_in_L]**-1; 

                            for pwr_y in range(0, self.p-1):
                                    y = self.K_gen ** pwr_y;
                                    z = self.K(x)*self.K(y);

                                    R[pwr_y, pwr_x] = L_char_val * jay(z, self.p, self.L, self.L_gen, self.L_char, self.K_char);

                                
                    # This is the circulant matrix we wanted (it is circulant)
                    #print("J");
                    #pretty_print(R.round(2));
                    #print("\n");

                    ## This is the diagonal matrix we wanted.
                    #print("M");
                    #print(M.round(2));
                    #print("\n");

                    #print("J*M");
                    #print((J*M).round(2));
                    #print("R");
                    #print(R.round(2));
                    #print(complex(round(R.trace().real_part()),round(R.trace().imag_part())));

                    #self.W_cached = J*M;
                    self.W_cached = R;
                    #R;

                return self.W_cached; #J * M; # TODO need COB or not?

        def W_inv(self):
                return self.W().inverse();

def rep(R, p, a, b, c, d):
    """ 
    Implements Bruhat decomposition 
    @a    :
    @b    :
    @c    :
    @d    :
    Return:
    """
    ring = IntegerModRing(p);

    a = ring(a);
    b = ring(b);
    c = ring(c);
    d = ring(d);

    #print(int(d*c**(-1)));

    if c % p == 0:
        bruhat = R.W()               \
               * R.U(int(-c*(a)**(-1)))   \
               * R.W()               \
               * R.T(int(-a))             \
               * R.U(int(b*a**(-1)));
    else:
        bruhat = R.U(int(a*c**(-1)))      \
               * R.W()               \
               * R.T(int(c))              \
               * R.U(int(d*c**(-1)));
    
    return bruhat; 


def TEST_SCHUR(R):

        p = R.p;
        W = R.W();

        ZERO = matrix(p-1);
        M1   = matrix(p-1);
        M2   = matrix(p-1);

        for t in range(1,p):
                for u in range(0,p):
                        for v in range(0,p):
                                M1 += R.T(t)*R.U(u)*W*R.U(v);

        for t in range(1,p):
                for u in range(0,p):
                        M2 += R.T(t)*R.U(u);

        # adult way would be to check their difference is < some epsilon
        return (M1 + M2).round(2) == ZERO

def TEST_W(R):
        W =  rep(R, R.p, 0, 1, -1, 0);
        Wi = rep(R, R.p, 0, -1, 1, 0);

        #print(W * Wi); # Should be identity
        return (W * Wi).round(2) == matrix.identity(R.p-1);

def TEST_THING(R):
        A  = rep(R, R.p, 1, 1, 0, 1);
        B  = rep(R, R.p, 1, -1, 0, 1);

        #print(A*B); # should be identity
        return (A*B).round(2) == matrix.identity(R.p-1);

def TEST_ORDER(R):
        A  = rep(R, R.p, 1, 1, 0, 1);
        Ap = A**R.p;

        B  = rep(R, R.p, 1, -1, 0, 1);
        Bp = B**R.p;

        #print(Ap);
        #print(Bp);

        return Ap.round(2) == Bp.round(2) == matrix.identity(R.p-1);

                            

def RUN_TESTS(p,g):

        X = nondecomposable_characters(p);

        print(X.round(2));

        for char in X.rows():
                if char[0] == 0 and char[1] == 0 and char[2] == 0:
                    continue;

                R = DiscreteSeriesRepresentation(p, g, char);

                #for x in R.L:
                    #print(x);

                #print('--');

                #for n in range(0, (R.p*R.p) - 1):
                    #print(n, R.L_gen**n);

                #print('--');

                #R.W();
                #exit();

                #print("schur");
                #TEST_SCHUR(R);
                #print("w");
                #TEST_W(R);
                #print("order");
                #TEST_ORDER(R);
                #print("thing");
                #TEST_THING(R);
                #print("--");
                print("Schur:"+str(TEST_SCHUR(R)));
                print("W:"+str(TEST_W(R)));
                print("ORDER:"+str(TEST_ORDER(R)));
                print("THING:"+str(TEST_THING(R)));
                print("----");




#RUN_TESTS(3, 2);        
#exit();



def second_largest_eigenvalue(matrix):

        evals = matrix.eigenvalues();

        print(evals);

        first  = complex(0);
        second = complex(0);

        for i in range(0, len(evals)):
                x = complex(evals[i]);
                if abs(x) > abs(second):
                        if abs(x) > abs(first):
                                second = first;
                                first = x;
                        else:
                                second = x;

        return second;


PRIMES = [
	3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 
	71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127
];

SMALL_PRIMES = [
	3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 
	71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127
];

SMALL_PRIMES_AND_GENERATORS = [
	(3, 2), (5, 2), (7, 3), (11, 2), (13, 2), (17, 3)#, (19, 2), (23, 5), 
	#(29, 2), (31, 3), (37, 2), (41, 6), (43, 3), (47, 5), (53, 2), (59, 2), 
	#(61, 2), (67, 2), (71, 7), (73, 5), (79, 3), (83, 2), (89, 3), (97, 5), 
	#(101, 2), (103, 5), (107, 2), (109, 6), (113, 3), (127, 3)
];

PRIMES_AND_GENERATORS = [
	(3, 2), (5, 2), (7, 3), (11, 2), (13, 2), (17, 3), (19, 2), (23, 5), 
	(29, 2), (31, 3), (37, 2), (41, 6), (43, 3), (47, 5), (53, 2), (59, 2), 
	(61, 2), (67, 2), (71, 7), (73, 5), (79, 3), (83, 2), (89, 3), (97, 5), 
	(101, 2), (103, 5), (107, 2), (109, 6), (113, 3)#, (127, 3)
];


def EXPERIMENT_spectrum_2():
	LD = [];
	LP = [];

	g1_csv = open("g1_spectrum_disc.csv", "w");

	g1_csv.write("line, p, multiplicity, evalue_scaled, evalue_real_part, evalue_imag_part\n");

	g1_line = 0;

        for p, g in SMALL_PRIMES_AND_GENERATORS:

                #if p > 3:
                    #exit();

                print("in prime:"+str(p)+" generator:"+str(g));

		chp = nondecomposable_characters_ucf(p);
                #for X in chp:
                    #for i in range(0, len(chp)-1):
                        #print(X[i]);
                    #print("\n");

                exit();

                #print(chp.round(2));

                # DISCRETE SERIES ALL eigenvalues
                #for i in range(0, (p**2)-1):
                for char in chp:
                        if char[0] == 0:
                                continue;

		        R = DiscreteSeriesRepresentation(p, g, char);

                        #if chp.row(i)[0] == 0.0:
                            #continue;

                        #print("Character:");
                        #print(chp.round(2).column(i));


			#W = R.W();
                        #exit();
                        
                        #try: 
                            #Winv = W.inverse();
                        #except ZeroDivisionError:
                            #continue;

                        
                        #continue;
			#Winv = W.inverse();

                        #g1 = r.U(1)       + r.U(p-1)     + W + Winv;
                        #A = rep(R, R.p, 1, 1, 0, 1);
                        #B = rep(R, R.p, 1, -1, 0, 1);
                        #C = rep(R, R.p, 0, 1, -1, 0);
                        #D = rep(R, R.p, 0, -1, 1, 0);

                        #A = rep(R, R.p, 1, (p+1)/2, 0, 1);
                        #B = rep(R, R.p, 1, (p-1)/2, 0, 1);
                        #C = rep(R, R.p, 0, 1, -1, 0);
                        #D = rep(R, R.p, 0, -1, 1, 0);

                        #g1 = A + B + C + D;

                        #print(round(g1.trace().real_part()));

                        g1 = R.U(1) + R.U(-1) + R.W() + R.W().inverse();

                        #g2 = r.U((p+1)/2) + r.U((p-1)/2) + W + Winv;
                        
                        for evalue, e, multiplicity in g1.eigenvectors_right(): 
				g1_csv.write("%d, %d, %d, %05f, %05f, %05fi\n" % (
					g1_line, 
					p, 
					multiplicity,
					float(evalue.real())/4.0,
					evalue.real(),
					evalue.imag()
                                ));
				g1_line += 1;

EXPERIMENT_spectrum_2();
exit();
